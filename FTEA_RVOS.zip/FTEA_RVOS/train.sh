python main.py -rm train -c configs/a2d_sentences.yaml -ws 8 -bs 1 -ng 1
