from .mttr import build


def build_model(args):
    return build(args)
